
package metodosdeordenamiento;

import java.util.Random;
import java.util.Scanner;
import metodosdeordenamiento.*;


public class MetodosdeOrdenamiento {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        
        System.out.print("Hola ¿De cuanto quiere el rango de la matriz?: ");
        int n = sc.nextInt();
        
        int[] arreglo = new int[n];
        
        Random random = new Random();
        
        for(int i=0; i<n;i++){
            arreglo[i] = random.nextInt(100);
        }
        
        System.out.println("Que tipo de ordenamiento quiere usar?: ");
        System.out.println("1.- Metodo Burbuja");
        System.out.println("2.- Metodo Seleccion");
        System.out.println("3.- Metodo Insercion Directa");
        System.out.println("4.- Metodo Shell");
        System.out.println("5.- Metodo Quicksort");
        int opcion = sc.nextInt();
        
        switch(opcion){
            case 1:
                MetodoBurbuja.burbuja(arreglo);
                break;
            case 2:
                MetodoSeleccion.seleccion(arreglo);
                break;
            case 3:
                MetodoInsercion.insercion(arreglo);
                break;
            case 4:
                MetodoShell.shell(arreglo);
                break;
            case 5:
                MetodoQuicksort.sort(arreglo);
                break;
            default:
                System.out.println("Opcion no valida.");
                break;
            
        }
        
        System.out.println("Arreglo ordenado: ");
        for (int i = 0; i < n; i++){
            System.out.print(arreglo[i]+ " , ");
        }
    }
    
}
