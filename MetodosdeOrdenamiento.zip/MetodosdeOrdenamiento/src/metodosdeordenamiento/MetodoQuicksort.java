
package metodosdeordenamiento;

public class MetodoQuicksort {
    
    public static void sort (int[]arreglo){
        quicksort(arreglo, 0 , arreglo.length - 1);
    }
    
    public static void quicksort (int[] arreglo, int low, int high){
        if(low < high){
            int pi = partition(arreglo, low, high);
            
            quicksort (arreglo, low, pi - 1);
            quicksort( arreglo, pi + 1, high);
        }
    }
    
    private static int partition (int[] arreglo, int low, int high){
        int pivot = arreglo[high];
        int i = low - 1;
        for (int j = low; j < high; j++){
            if (arreglo[j] < pivot){
                i++;
                swap (arreglo, i, j);
                
            }
        }
        swap (arreglo, i + 1, high);               
        return i+1;
    }
    
    private static void swap (int[] arreglo, int i, int j){
        int temp = arreglo[i];
        arreglo[i] = arreglo[j];
        arreglo[j]= temp;
    }

}