
package recursividad;

public class Hanoi {
    
    public static void hanoi(int n, char origen, char destino, char auxiliar) {
        if (n == 1) {
            System.out.println("Mover disco 1 desde " + origen + " hacia " + destino);
        } else {
            hanoi(n - 1, origen, auxiliar, destino);
            System.out.println("Mover disco " + n + " desde " + origen + " hacia " + destino);
            hanoi(n - 1, auxiliar, destino, origen);
        }
    }
    
}
