package recursividad;

import java.util.Scanner;

public class Recursividad {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        
        System.out.println("¿Que tipo de recursividad quiere ver?: ");
        
        System.out.println("1. Ackermann");
        System.out.println("2. Torre de Hanoi");
        
        int opcion = sc.nextInt();
        switch(opcion){
            case 1:
                int resultadoAck = Ackermann.ackermann(2, 3);
        System.out.println("El resultado de la función de Ackermann es: " + resultadoAck);
                break;
            case 2:
                int numDiscos = 3;
        System.out.println("El resultadp de la funcion de Hanoi es: ");
        Hanoi.hanoi(numDiscos, 'A', 'C', 'B');
                break;
            default:
                System.out.println("Opcion no valida, ingrese otra");
        }

    }

}
