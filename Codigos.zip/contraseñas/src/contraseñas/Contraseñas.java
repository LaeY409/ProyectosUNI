package contraseñas;

public class Contraseñas {

    public static void main(String[] args) {
        testLogin();
        testHackeo();
    }

    public static void testLogin() {
        SesionDeUsuario sesionDeUsuario = new SesionDeUsuario();
        sesionDeUsuario.setUsuario("sofia");
        sesionDeUsuario.setPassword("uvwxyz");
        sesionDeUsuario.doLogin();
        if (sesionDeUsuario.isLoggedIn()) {
            System.out.println("Bienvenido " + sesionDeUsuario.getUsuario());
        } else {
            System.out.println("Su usuario o contraseña estan equivocados");
        }
        sesionDeUsuario.setPassword("abcdef");
        sesionDeUsuario.doLogin();
        if (sesionDeUsuario.isLoggedIn()) {
            System.out.println("Bienvenido " + sesionDeUsuario.getUsuario());
        } else {
            System.out.println("Su usuario o contraseña estan equivocados");
        }
    }

    public static void testHackeo() {
  //  SesionDeUsuario sesionDeUsuario = new SesionDeUsuario();
  //  sesionDeUsuario.getPassword();   ~La linea no compila ya que intenta acceder a una variable de solo escritura, asi que no
  //tiene getter
  //  sesionDeUsuario.setLoggedIn(true);   Esta no compila ya que esta intentando modificar una variable de solo lectura~
  
    }
}

