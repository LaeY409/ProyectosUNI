
package binaria;

public class Binaria {

    public static void main(String[] args) {

        int[] arreglo = {1, 3, 5, 7, 9, 11, 13};
        int objetivo = 7;

        int indice = BusquedaBinaria.busquedaBinariaRecursiva(arreglo, objetivo);

        if (indice != -1) {
            System.out.println("El elemento " + objetivo + " se encuentra en el índice " + indice + ".");
        } else {
            System.out.println("El elemento " + objetivo + " no se encuentra en el arreglo.");
        }
    }
}
