
package binaria;

public class BusquedaBinaria {
    
    // Método de búsqueda binaria recursiva
    public static int busquedaBinariaRecursiva(int[] arr, int objetivo) {
        return busquedaBinariaRecursiva(arr, objetivo, 0, arr.length - 1);
    }

    private static int busquedaBinariaRecursiva(int[] arr, int objetivo, int izquierda, int derecha) {
        if (izquierda > derecha) {
            return -1; // Elemento no encontrado
        }

        int medio = (izquierda + derecha) / 2;

        if (arr[medio] == objetivo) {
            return medio; // Elemento encontrado
        } else if (arr[medio] < objetivo) {
            return busquedaBinariaRecursiva(arr, objetivo, medio + 1, derecha);
        } else {
            return busquedaBinariaRecursiva(arr, objetivo, izquierda, medio - 1);
        }
    }
}
